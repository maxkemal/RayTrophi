#ifndef VEC3SIMD_H
#define VEC3SIMD_H

#include <immintrin.h> // AVX header
#include <cmath>
#include <random>
#include <iostream>
#include <stdexcept>
#include <algorithm>
#include <limits>

// M_PI'yi float olarak tan�mla
#define M_PI 3.14159265358979323846f

// �NEML�: Vec3SIMD, 8 farkl� float'� (�rne�in 8 farkl� ���n�n X bile�enini) tutar.
class Vec3SIMD {
public:
    __m256 data;

    // --- Constructors ---
    Vec3SIMD();
    Vec3SIMD(__m256 d);
    Vec3SIMD(float val); // set1

    // Tek bir 3D Vekt�r� AVX'e Y�kler (�lk 3 bile�eni doldurur, di�erleri 0)
    // D�KKAT: Yava�lamaya neden olabilir, sadece skaler entegrasyon i�in.
    Vec3SIMD(float x, float y, float z);

    // Array Constructor
    Vec3SIMD(const float arr[8]);

    // --- Access Operators (Yava�, Skaler Kod ile Uyum ��in Korundu) ---
    float x() const;
    float y() const;
    float z() const;
    float get(int index) const; // Genel indeksli eri�im
    float operator[](int i) const { return get(i); } // [] operat�r�

    // --- Aritmetik Operat�rler (8x Paralel) ---
    Vec3SIMD operator-() const;

    Vec3SIMD& operator+=(const Vec3SIMD& v);
    Vec3SIMD& operator-=(const Vec3SIMD& v);
    Vec3SIMD& operator*=(const Vec3SIMD& v);
    Vec3SIMD& operator/=(const Vec3SIMD& v);

    Vec3SIMD& operator*=(float t);
    Vec3SIMD& operator/=(float t);

    Vec3SIMD operator-(float scalar) const;
    Vec3SIMD operator+(float scalar) const;
    Vec3SIMD operator*(float scalar) const;
    Vec3SIMD operator/(float scalar) const;

    // --- Kar��la�t�rma Operat�rleri (8x Paralel, __m256 Maskesi D�nd�r�r) ---
    __m256 operator==(const Vec3SIMD& other) const;
    __m256 operator!=(const Vec3SIMD& other) const;

    // --- Temel Matematik (8x Paralel) ---
    Vec3SIMD abs() const;
    Vec3SIMD sqrt() const;

    // --- Statik Yard�mc� Metotlar (Paket Tabanl�) ---
    static Vec3SIMD set1(float val);
    static Vec3SIMD setZero();

    // �o�u bu statik metotlar� �a��r�r, 3 bile�enin hepsini i�ler:

    // 8x Nokta �arp�m: Geriye 8 sonucu i�eren __m256 d�nd�r�r.
    static __m256 dot_product_8x(const Vec3SIMD& u_x, const Vec3SIMD& u_y, const Vec3SIMD& u_z,
        const Vec3SIMD& v_x, const Vec3SIMD& v_y, const Vec3SIMD& v_z);

    // 8x Uzunluk Karesi: Geriye 8 sonucu i�eren __m256 d�nd�r�r.
    static __m256 length_squared_8x(const Vec3SIMD& u_x, const Vec3SIMD& u_y, const Vec3SIMD& u_z);

    // 8x Normalizasyon: Geriye normalize edilmi� 3 bile�eni d�nd�r�r.
    static void normalize_8x(const Vec3SIMD& u_x, const Vec3SIMD& u_y, const Vec3SIMD& u_z,
        Vec3SIMD& out_x, Vec3SIMD& out_y, Vec3SIMD& out_z);

    // 8x �apraz �arp�m (Cross Product): Geriye 3 bile�eni d�nd�r�r.
    static void cross_8x(const Vec3SIMD& u_x, const Vec3SIMD& u_y, const Vec3SIMD& u_z,
        const Vec3SIMD& v_x, const Vec3SIMD& v_y, const Vec3SIMD& v_z,
        Vec3SIMD& out_x, Vec3SIMD& out_y, Vec3SIMD& out_z);

    // 8x Yans�ma (Reflect)
    static void reflect_8x(const Vec3SIMD& v_x, const Vec3SIMD& v_y, const Vec3SIMD& v_z,
        const Vec3SIMD& n_x, const Vec3SIMD& n_y, const Vec3SIMD& n_z,
        Vec3SIMD& out_x, Vec3SIMD& out_y, Vec3SIMD& out_z);

    // 8x K�r�lma (Refract)
    static void refract_8x(const Vec3SIMD& uv_x, const Vec3SIMD& uv_y, const Vec3SIMD& uv_z,
        const Vec3SIMD& n_x, const Vec3SIMD& n_y, const Vec3SIMD& n_z,
        const Vec3SIMD& etai_over_etat,
        Vec3SIMD& out_x, Vec3SIMD& out_y, Vec3SIMD& out_z);


    // --- Skaler Uyum ve Legacy Metotlar (Yava�) ---
    // Bu metotlar AVX'in performans�n� d���r�r, sadece tekil test/kullan�m i�in saklanm��t�r.
    float length() const;
    float length_squared() const;
    float dot(const Vec3SIMD& other) const; // Tek bir skaler de�er d�nd�r�r (Hadd gerektirir)
    bool near_zero() const; // Tek bir vekt�r i�in kontrol
    float max_component() const; // Tek bir vekt�r i�in kontrol

    // --- Skaler-SIMD Uyum Metotlar� ---
    static Vec3SIMD max(const Vec3SIMD& v, float scalar);
    static Vec3SIMD clamp(const Vec3SIMD& v, float minVal, float maxVal);
    static Vec3SIMD pow(const Vec3SIMD& v, float exponent);

    // --- Skaler Random Metotlar (Yava�) ---
    static float random_float();
    static void random_unit_vector_8x(Vec3SIMD& out_x, Vec3SIMD& out_y, Vec3SIMD& out_z);

private:
    static std::mt19937 rng;
    static std::uniform_real_distribution<float> dist;
};

// --- Friend Fonksiyonlar (8x Paralel) ---
Vec3SIMD operator+(const Vec3SIMD& u, const Vec3SIMD& v);
Vec3SIMD operator-(const Vec3SIMD& u, const Vec3SIMD& v);
Vec3SIMD operator*(const Vec3SIMD& u, const Vec3SIMD& v);
Vec3SIMD operator/(const Vec3SIMD& u, const Vec3SIMD& v);
Vec3SIMD operator*(float t, const Vec3SIMD& v);
Vec3SIMD operator/(const Vec3SIMD& v, float t);

#endif // VEC3SIMD_H