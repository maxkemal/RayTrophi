﻿#ifndef TRIANGLE_H
#define TRIANGLE_H

#include <memory>
#include <string>
#include <algorithm>
#include "Hittable.h"
#include "Material.h"
#include "Vec2.h"
#include "Matrix4x4.h"
#include "Vec3SIMD.h"
#include <SDL.h>
#include <SDL_image.h>

class Triangle : public Hittable {
public:
    std::string materialName;
    // Animasyon için: her vertexin bone ağırlıkları
    std::vector<std::vector<std::pair<int, float>>> vertexBoneWeights;  // [vertex][(boneIndex, weight)]

    inline void setFaceIndex(int idx) { faceIndex = idx; }
    inline int getFaceIndex() const { return faceIndex; }

    // Animasyon için: her vertexin orijinal bind pose pozisyonu
    std::vector<Vec3> originalVertexPositions;

    // Orijinal (başlangıç) vertex pozisyonları
    Vec3 original_v0, original_v1, original_v2;
    // Orijinal (başlangıç) normallar
    Vec3 original_n0, original_n1, original_n2;

    // Dönüştürülmüş haller
    Vec3 transformed_v0, transformed_v1, transformed_v2;
    Vec3 transformed_n0, transformed_n1, transformed_n2;

    // Vertices ve normals (hit detection için)
    Vec3 v0, v1, v2;        // vertices
    Vec3 n0, n1, n2;        // normals
    Vec2 t0, t1, t2;        // texture coordinates

    std::shared_ptr<Material> mat_ptr;
    std::shared_ptr<GpuMaterial> gpuMaterialPtr;
    OptixGeometryData::TextureBundle textureBundle;
   // int smoothingGroup;

    Matrix4x4 transform;
    std::shared_ptr<Texture> texture;

    // Default constructor
    Triangle();
    Triangle(const Vec3& a, const Vec3& b, const Vec3& c,
        const Vec3& na, const Vec3& nb, const Vec3& nc,
        const Vec2& ta, const Vec2& tb, const Vec2& tc,
        std::shared_ptr<Material> m);

    inline bool has_tangent_basis() const { return false; }

    void setUVCoordinates(const Vec2& uv0, const Vec2& uv1, const Vec2& uv2);
    std::tuple<Vec2, Vec2, Vec2> getUVCoordinates() const;

    void set_transform(const Matrix4x4& t);
    static void updateTriangleTransform(Triangle& triangle, const Matrix4x4& transform);

    //void render(SDL_Renderer* renderer, SDL_Texture* texture);

    // Set normals
    void set_normals(const Vec3& normal0, const Vec3& normal1, const Vec3& normal2);

    void setAssimpVertexIndices(unsigned int i0, unsigned int i1, unsigned int i2) {
        assimpVertexIndices = { i0, i1, i2 };
    }

    inline const std::array<unsigned int, 3>& getAssimpVertexIndices() const {
        return assimpVertexIndices;
    }

    inline std::shared_ptr<Material> getMaterial() const {
        return mat_ptr;
    }

    void setMaterial(const std::shared_ptr<Material>& mat) {
        mat_ptr = mat;
    }

    inline const std::string& getNodeName() const {
        return nodeName;
    }

    virtual bool hit(const Ray& r, float t_min, float t_max, HitRecord& rec) const override;

    void updateTransformedVertices();
    void setNodeName(const std::string& name);
    void setBaseTransform(const Matrix4x4& transform);
    void initialize_transforms();
    void updateAnimationTransform(const Matrix4x4& animTransform);

    virtual bool bounding_box(float time0, float time1, AABB& output_box) const override;
    void update_bounding_box();

    Vec3 apply_bone_to_vertex(int vi, const std::vector<Matrix4x4>& finalBoneMatrices) const;
    void apply_skinning(const std::vector<Matrix4x4>& finalBoneMatrices);
    Vec3 apply_bone_to_normal(const Vec3& originalNormal,
        const std::vector<std::pair<int, float>>& boneWeights,
        const std::vector<Matrix4x4>& finalBoneMatrices) const;

private:
    std::string nodeName;
    Matrix4x4 baseTransform;
    Matrix4x4 currentTransform;
    Matrix4x4 finalTransform;

    Vec3 min_point;
    Vec3 max_point;

    Vec2 uv0, uv1, uv2;
    int faceIndex = -1;
    std::array<unsigned int, 3> assimpVertexIndices;

    // Scratch buffers for apply_skinning
    mutable Vec3 blendedPos, blendedNorm;
};

#endif // TRIANGLE_H