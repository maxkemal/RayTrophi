﻿#include "Light.h"

// Default constructor implementation
//Light::Light() : position(Vec3()), intensity(Vec3()), direction(Vec3()), u(Vec3()), v(Vec3()), width(0), height(0) {}
 // Varsayılan constructor eklendi
//Light::Light() : position(0, 0, 0), intensity(1, 1, 1), direction(0, 1, 0), u(1, 0, 0), v(0, 0, 1), width(1), height(1) {}
// You can add other member function implementations if needed
